#pragma once

char *infixToPostfix(char *infixNotation, int inputLength);
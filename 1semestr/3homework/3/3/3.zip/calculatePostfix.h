#pragma once

double calculatePostfix(char *postfixExpression);